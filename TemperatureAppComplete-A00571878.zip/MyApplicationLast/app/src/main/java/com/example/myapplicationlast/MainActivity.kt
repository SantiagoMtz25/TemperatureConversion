package com.example.myapplicationlast

import android.os.Bundle
import android.widget.RadioButton
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButtonColors
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.myapplicationlast.ui.theme.MyApplicationLastTheme
import com.example.myapplicationlast.R

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationLastTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    WeatherConverterScreen()
                }
            }
        }
    }
}

@Composable
fun CustomRadioButton (
    selected: Boolean,
    onClick: (() -> Unit)?,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    interactionSource: MutableInteractionSource = remember { MutableInteractionSource() }
) {
    val colorScheme = MaterialTheme.colorScheme  // Accessing colorScheme within the composable body

    Box(
        modifier = modifier
            .size(24.dp)
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null
            ) {
                onClick?.invoke()
            },
        contentAlignment = Alignment.Center
    ) {
        // Outer circle
        Canvas(modifier = Modifier.size(24.dp)) {
            drawCircle(
                color = colorScheme.onSurface,  // Use the local variable
                radius = size.width / 2
            )
        }

        // Inner circle if selected
        if (selected) {
            Canvas(modifier = Modifier.size(16.dp)) {
                drawCircle(
                    color = colorScheme.primary,  // Use the local variable
                    radius = size.width / 2
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun WeatherConverterScreen(){
    var celsiusValue by rememberSaveable { mutableStateOf(value = "") }
    var fahrenheitValue by rememberSaveable { mutableStateOf(value = "") }
    var state by rememberSaveable { mutableStateOf(true) } // true for Celsius, false for Fahrenheit

    Column (modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
            value = celsiusValue,
            onValueChange = { celsiusValue = it },
            label = { Text(text = "Temperature") },
            keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row (Modifier.selectableGroup()) {
            CustomRadioButton (
                selected = state,
                onClick = { state = true }
            )
            Text("Celsius", modifier = Modifier.padding(start = 8.dp))
            Spacer(modifier = Modifier.width(16.dp))
            CustomRadioButton(
                selected = !state,
                onClick = { state = false }
            )
            Text("Fahrenheit", modifier = Modifier.padding(start = 8.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = {
            if (state && celsiusValue.isNotBlank()) {  // User inputs Celsius, convert to Fahrenheit
                val celsius = celsiusValue.toDouble()
                val fahrenheit = celsius * 9 / 5 + 32
                fahrenheitValue = fahrenheit.toString()
            } else if (!state && celsiusValue.isNotBlank()) {  // User inputs Fahrenheit, convert to Celsius
                val fahrenheit = celsiusValue.toDouble()
                val celsius = (fahrenheit - 32) * 5 / 9
                celsiusValue = celsius.toString()
            }
        }) {
            Text(stringResource(R.string.convert_message))
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = if(state) "Fahrenheit: $fahrenheitValue" else "Celsius: $celsiusValue")
    }
}